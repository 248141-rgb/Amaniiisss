import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Moon, Sun, Menu, X, Mail, Github, Linkedin, Twitter, ExternalLink, ChevronUp, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

// Assets
import profileImg from "@assets/stock_images/professional_busines_839833b9.jpg";
import project1Img from "@assets/stock_images/business_process_aut_32b2edd7.jpg";
import project2Img from "@assets/stock_images/modern_business_anal_92cca95e.jpg";
import project3Img from "@assets/stock_images/digital_transformati_357e4975.jpg";

// --- Data ---
const personalInfo = {
  name: "Amani Soud Mahariq",
  profession: "Business Technology Student",
  tagline: "I create smart, simple digital solutions that help businesses work better.",
  bio: "I'm Amani, a Business Technology student interested in digital systems, data tools, and modern business solutions. I enjoy working with technology to improve productivity, analyze data, and support smarter decision-making.",
  email: "248141@ppu.edu.ps",
  socials: {
    facebook: "https://www.facebook.com/share/1V3jCzz6AW/",
    github: "#",
    linkedin: "#",
    twitter: "#"
  }
};

const skills = [
  { name: "HTML", level: 90 },
  { name: "CSS", level: 80 },
  { name: "Bootstrap", level: 90 },
  { name: "Python", level: 75 },
  { name: "Microsoft Office", level: 95 },
  { name: "Canva", level: 90 },
  { name: "Business Analysis", level: 85 },
  { name: "Communication", level: 90 }
];

const projects = [
  {
    id: 1,
    title: "Business Process Automation Model",
    description: "A simple workflow automation model that simulates how a small business can reduce manual steps using digital tools and structured processes.",
    image: project1Img,
    link: "https://demo.getform.io/"
  },
  {
    id: 2,
    title: "Interactive Business Dashboard",
    description: "A clean, modern dashboard that visualizes sales, customer segments, and performance metrics. Perfect example of data visualization in business tech.",
    image: project2Img,
    link: "https://github.com/creativetimofficial/light-bootstrap-dashboard"
  },
  {
    id: 3,
    title: "Digital Transformation Case Study",
    description: "A structured case study showing how a company can transition from manual processes to digital systems, including workflow mapping and recommendations.",
    image: project3Img,
    link: "https://www2.deloitte.com/content/dam/Deloitte/global/Documents/Technology/gx-cons-digital-transformation.pdf"
  }
];

const formSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  message: z.string().min(10, { message: "Message must be at least 10 characters." }),
});

// --- Components ---

const Section = ({ id, className, children }: { id: string, className?: string, children: React.ReactNode }) => (
  <section id={id} className={`py-20 md:py-32 px-4 md:px-8 ${className}`}>
    <div className="max-w-6xl mx-auto">
      {children}
    </div>
  </section>
);

const NavBar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [theme, setTheme] = useState<"light" | "dark">("light");

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    if (theme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [theme]);

  const toggleTheme = () => setTheme(theme === "light" ? "dark" : "light");

  const navLinks = [
    { name: "Home", href: "#home" },
    { name: "About", href: "#about" },
    { name: "Skills", href: "#skills" },
    { name: "Projects", href: "#projects" },
    { name: "Contact", href: "#contact" },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? "bg-background/80 backdrop-blur-md shadow-sm py-4" : "bg-transparent py-6"}`}>
      <div className="max-w-7xl mx-auto px-4 md:px-8 flex justify-between items-center">
        <a href="#" className="text-2xl font-serif font-bold tracking-tighter hover:opacity-80 transition-opacity">
          Amani<span className="text-primary">.</span>
        </a>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href} 
              className="text-sm font-medium hover:text-primary transition-colors relative group"
            >
              {link.name}
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all group-hover:w-full"></span>
            </a>
          ))}
          <Button variant="ghost" size="icon" onClick={toggleTheme} className="rounded-full">
            {theme === "light" ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
          </Button>
        </div>

        {/* Mobile Nav Toggle */}
        <div className="md:hidden flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={toggleTheme} className="rounded-full">
            {theme === "light" ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
          </Button>
          <Button variant="ghost" size="icon" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-background border-b"
          >
            <div className="flex flex-col p-4 gap-4">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className="text-lg font-medium py-2 border-b border-border/50 last:border-0"
                  onClick={() => setIsOpen(false)}
                >
                  {link.name}
                </a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default function Home() {
  const { toast } = useToast();
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      message: "",
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    // Construct mailto link
    const subject = `Portfolio Contact from ${values.name}`;
    const body = `${values.message}\n\nFrom: ${values.name} (${values.email})`;
    window.location.href = `mailto:${personalInfo.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    
    toast({
      title: "Opening email client...",
      description: "Your message is ready to send.",
    });
    form.reset();
  }

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-background text-foreground selection:bg-primary/20">
      <NavBar />

      <main>
        {/* Hero Section */}
        <Section id="home" className="min-h-screen flex items-center pt-32">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <span className="text-primary font-medium tracking-wide uppercase text-sm">Welcome</span>
              <h1 className="text-5xl md:text-7xl font-bold mt-4 mb-6 leading-tight">
                Hi, I'm <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-purple-600">
                  {personalInfo.name.split(" ")[0]} {personalInfo.name.split(" ")[1]}
                </span>
              </h1>
              <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-lg leading-relaxed">
                {personalInfo.tagline}
              </p>
              <div className="flex gap-4">
                <Button size="lg" className="rounded-full text-base px-8 h-12" asChild>
                  <a href="#contact">Get in Touch</a>
                </Button>
                <Button size="lg" variant="outline" className="rounded-full text-base px-8 h-12" asChild>
                  <a href="#projects">View Projects</a>
                </Button>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="relative hidden md:block"
            >
              <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-purple-500/20 rounded-full blur-3xl opacity-70 animate-pulse"></div>
              <img 
                src={profileImg} 
                alt={personalInfo.name} 
                className="relative z-10 w-full max-w-md mx-auto rounded-2xl shadow-2xl object-cover aspect-[4/5]"
              />
            </motion.div>
          </div>
        </Section>

        {/* About Section */}
        <Section id="about" className="bg-secondary/30">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="grid md:grid-cols-2 gap-16 items-center"
          >
            <div className="relative order-2 md:order-1">
              <div className="aspect-square bg-muted rounded-2xl overflow-hidden shadow-xl">
                 <img 
                  src={profileImg} 
                  alt="About Me" 
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 w-48 h-48 bg-background p-6 rounded-xl shadow-lg border flex flex-col justify-center items-center text-center hidden md:flex">
                <span className="text-4xl font-bold text-primary">3+</span>
                <span className="text-sm font-medium text-muted-foreground mt-2">Years Studying Business Tech</span>
              </div>
            </div>
            <div className="order-1 md:order-2">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">About Me</h2>
              <h3 className="text-xl font-medium text-primary mb-4">{personalInfo.profession}</h3>
              <p className="text-lg text-muted-foreground leading-relaxed mb-6">
                {personalInfo.bio}
              </p>
              <div className="grid grid-cols-2 gap-4 mb-8">
                <div>
                  <span className="block text-sm text-muted-foreground mb-1">Email</span>
                  <a href={`mailto:${personalInfo.email}`} className="font-medium hover:text-primary">{personalInfo.email}</a>
                </div>
                <div>
                  <span className="block text-sm text-muted-foreground mb-1">From</span>
                  <span className="font-medium">Hebron, Palestine</span>
                </div>
              </div>
              <Button variant="outline" className="gap-2">
                Download Resume <Download className="h-4 w-4" />
              </Button>
            </div>
          </motion.div>
        </Section>

        {/* Skills Section */}
        <Section id="skills">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Technical & Business Skills</h2>
            <p className="text-muted-foreground">My expertise combines technical proficiency with business acumen to deliver holistic solutions.</p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-x-12 gap-y-8">
            {skills.map((skill, index) => (
              <motion.div
                key={skill.name}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <div className="flex justify-between mb-2">
                  <span className="font-medium">{skill.name}</span>
                  <span className="text-muted-foreground">{skill.level}%</span>
                </div>
                <Progress value={skill.level} className="h-2" />
              </motion.div>
            ))}
          </div>
        </Section>

        {/* Projects Section */}
        <Section id="projects" className="bg-secondary/30">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Featured Projects</h2>
            <p className="text-muted-foreground">A selection of my work in business process automation, data visualization, and digital transformation.</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
              >
                <Card className="h-full flex flex-col overflow-hidden group border-none shadow-md hover:shadow-xl transition-all duration-300 bg-card">
                  <div className="relative h-48 overflow-hidden">
                    <img 
                      src={project.image} 
                      alt={project.title} 
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Button variant="secondary" size="sm" className="gap-2 rounded-full" asChild>
                        <a href={project.link} target="_blank" rel="noopener noreferrer">
                          View Project <ExternalLink className="h-4 w-4" />
                        </a>
                      </Button>
                    </div>
                  </div>
                  <CardHeader>
                    <CardTitle className="text-xl">{project.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="flex-grow">
                    <CardDescription className="text-base">
                      {project.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </Section>

        {/* Contact Section */}
        <Section id="contact">
          <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Let's Work Together</h2>
              <p className="text-lg text-muted-foreground mb-8">
                I'm currently available for internships and freelance projects. If you have a project that needs some creative touch, let's chat.
              </p>
              
              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="bg-primary/10 p-3 rounded-full text-primary">
                    <Mail className="h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Email</h4>
                    <a href={`mailto:${personalInfo.email}`} className="text-muted-foreground hover:text-primary">{personalInfo.email}</a>
                  </div>
                </div>
                
                <div className="flex gap-4 mt-8">
                  {Object.entries(personalInfo.socials).map(([platform, link]) => (
                    <a 
                      key={platform} 
                      href={link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-secondary hover:bg-primary hover:text-primary-foreground p-3 rounded-full transition-colors"
                    >
                      {platform === "github" && <Github className="h-5 w-5" />}
                      {platform === "linkedin" && <Linkedin className="h-5 w-5" />}
                      {platform === "twitter" && <Twitter className="h-5 w-5" />}
                      {platform === "facebook" && <ExternalLink className="h-5 w-5" />}
                    </a>
                  ))}
                </div>
              </div>
            </div>

            <Card className="shadow-lg border-none bg-secondary/20">
              <CardHeader>
                <CardTitle>Send Message</CardTitle>
                <CardDescription>I'll get back to you as soon as possible.</CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Your Name" {...field} className="bg-background" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input placeholder="your@email.com" {...field} className="bg-background" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="message"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Message</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="How can I help you?" 
                              className="resize-none bg-background" 
                              rows={4}
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button type="submit" className="w-full">Send Message</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>
        </Section>
      </main>

      {/* Footer */}
      <footer className="bg-secondary py-12 px-4 border-t">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="text-center md:text-left">
            <span className="text-xl font-serif font-bold">Amani.</span>
            <p className="text-sm text-muted-foreground mt-2">
              © {new Date().getFullYear()} Amani Soud Mahariq. All rights reserved.
            </p>
          </div>
          
          <div className="flex items-center gap-6">
            <button 
              onClick={scrollToTop}
              className="flex items-center gap-2 text-sm font-medium hover:text-primary transition-colors"
            >
              Back to Top <ChevronUp className="h-4 w-4" />
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
